"use client";

import { AppShell } from "@/components/AppShell";
import { ButtonLink } from "@/components/ButtonLink";
import { useRecords } from "@/data/RecordsProvider";

export default function Home() {
  const { today, currentStreak } = useRecords();

  return (
    <AppShell>
      <section className="space-y-5">
        <div className="rounded-full bg-orange-100 px-4 py-3 text-sm font-bold text-orange-800">
          🔥 {currentStreak || 1}日連続
          <span className="ml-2 font-normal text-orange-700">今日も続けよう。</span>
        </div>

        <div>
          <p className="text-sm font-bold text-orange-700">人間力向上委員会</p>
          <h1 className="mt-2 text-4xl font-bold leading-tight text-stone-950">今日も、自分と5分話そう。</h1>
          <p className="mt-4 leading-7 text-stone-700">
            今日は少しだけ、自分と向き合う時間をつくりましょう。今日のテーマについて5分だけ振り返るだけで大丈夫です。
          </p>
        </div>

        <article className="warm-panel rounded-lg p-5 md:p-7">
          <p className="text-lg font-bold text-orange-700">🌱 今日の一歩</p>
          <div className="mt-5 rounded-lg bg-orange-50 p-4">
            <p className="text-sm font-bold text-orange-700">今日のテーマ</p>
            <h2 className="mt-2 text-4xl font-bold text-stone-950">
              <span className="mr-2">{today.icon}</span>
              {today.theme}
            </h2>
          </div>
          <div className="mt-4 rounded-lg bg-amber-50 p-4">
            <p className="text-sm font-bold text-amber-800">今日は</p>
            <p className="mt-2 text-xl font-bold leading-8 text-stone-900">
              「{today.shortQuestion}」
              <br />
              について話してみましょう。
            </p>
          </div>
          <p className="mt-4 text-sm font-bold text-stone-500">今日の振り返り時間：約5分</p>
        </article>

        <div>
          <ButtonLink href="/reflection/new">今日の5分振り返りを書く</ButtonLink>
          <p className="mt-2 text-center text-sm text-stone-500">
            書いた内容はあなた専属のチャッピーに蓄積されます
          </p>
        </div>

        <article className="rounded-lg border border-orange-100 bg-white/60 p-5">
          <p className="font-bold text-orange-700">🌱 今日のつなぐん</p>
          <p className="mt-3 whitespace-pre-line text-lg font-bold leading-8 text-stone-800">{today.tsunagunMessage}</p>
        </article>

        <div className="grid gap-3 sm:grid-cols-2">
          <ButtonLink href="/chappy" variant="secondary">
            ChatGPTでじっくり話す
          </ButtonLink>
          <ButtonLink href="/community" variant="secondary">
            みんなの振り返りを見る
          </ButtonLink>
        </div>
      </section>
    </AppShell>
  );
}
